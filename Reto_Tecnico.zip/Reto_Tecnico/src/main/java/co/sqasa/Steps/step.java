package co.sqasa.Steps;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.Keys;

import static co.sqasa.pageObjects.Objects.*;

public class step extends PageObject
{

    @Step("Abrir la página del calendario")
    public void abrirPagina()
    {
        getDriver().get("https://jqueryui.com/datepicker/");
    }

    @Step("Cambiar al iframe del calendario")
    public void cambiarIframe()
    {
        getDriver().switchTo().frame(find(MARCO_IFRAME).getWrappedElement());
    }

    @Step("Seleccionar el día {0} del mes actual")
    public void seleccionarDiaActual(int dia)
    {
        cambiarIframe();
        find(CAMPO_FECHA).click();
        find(DIA(dia)).click();
        getDriver().switchTo().defaultContent();
    }

    @Step("Seleccionar el día {0} del próximo mes")
    public void seleccionarDiaProximo(int dia)
    {
        cambiarIframe();
        find(CAMPO_FECHA).click();
        find(BOTON_SIGUIENTE_MES).click();
        find(DIA(dia)).click();
        getDriver().switchTo().defaultContent();
    }

    @Step("Validar fecha mostrada")
    public boolean validarFecha()
    {
        cambiarIframe();
        String valor = find(CAMPO_FECHA).getValue();
        getDriver().switchTo().defaultContent();
        return !valor.isEmpty();
    }

    @Step("Intentar escribir manualmente una fecha")
    public void escribirManual()
    {
        cambiarIframe();
        find(CAMPO_FECHA).sendKeys(Keys.chord(Keys.CONTROL, "a"), "12/12/2025");
        getDriver().switchTo().defaultContent();
    }

    @Step("Validar que no permite escritura manual")
    public boolean campoBloqueado()
    {
        cambiarIframe();
        String valor = find(CAMPO_FECHA).getValue();
        getDriver().switchTo().defaultContent();
        return valor.isEmpty();
    }
}
