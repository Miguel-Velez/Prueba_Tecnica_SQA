package co.sqasa.Steps;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.Keys;

import static co.sqasa.pageObjects.Objects.*;

public class Steps extends PageObject
{

    @Step("Abrir página principal")
    public void abrirPagina()
    {
        getDriver().get("https://jqueryui.com/datepicker/");
    }

    @Step("Seleccionar día actual {0}")
    public void seleccionarDiaActual(int dia)
    {
        getDriver().switchTo().frame(find(MARCO_IFRAME).getWrappedElement());
        find(CAMPO_FECHA).click();
        find(DIA(dia)).click();
    }

    @Step("Seleccionar día próximo {0}")
    public void seleccionarDiaProximo(int dia)
    {
        getDriver().switchTo().frame(find(MARCO_IFRAME).getWrappedElement());
        find(CAMPO_FECHA).click();
        find(BOTON_SIGUIENTE_MES).click();
        find(DIA(dia)).click();
    }

    @Step("Validar fecha visible")
    public boolean validarFecha()
    {
        return !find(CAMPO_FECHA).getValue().isEmpty();
    }

    @Step("Intentar escribir manualmente")
    public void escribirManual()
    {
        getDriver().switchTo().frame(find(MARCO_IFRAME).getWrappedElement());
        find(CAMPO_FECHA).sendKeys(Keys.chord(Keys.CONTROL, "a"), "12/12/2025");
    }

    @Step("Validar campo bloqueado")
    public boolean campoBloqueado()
    {
        return find(CAMPO_FECHA).getValue().isEmpty();
    }
}
