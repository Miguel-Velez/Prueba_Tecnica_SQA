package co.sqasa.pageObjects;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class Objects extends PageObject
{

    public static final By MARCO_IFRAME = By.cssSelector(".demo-frame");
    public static final By CAMPO_FECHA = By.id("datepicker");
    public static final By BOTON_SIGUIENTE_MES = By.cssSelector(".ui-datepicker-next");

    public static By DIA(int numeroDia)
    {
        return By.xpath("//a[text()='" + numeroDia + "']");
    }
}
