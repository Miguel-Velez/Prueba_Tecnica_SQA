package co.sqasa.StepDef;

import co.sqasa.Steps.Steps;
import io.cucumber.java.es.*;
import org.junit.Assert;

public class TestStepDefinition
{

    Steps acciones = new Steps();

    @Dado("que el usuario abre la página del calendario")
    public void abrirPagina() {
        acciones.abrirPagina();
    }

    @Cuando("selecciona el día {int} del mes actual")
    public void seleccionarDiaActual(Integer dia) {
        acciones.seleccionarDiaActual(dia);
    }

    @Cuando("selecciona el día {int} del próximo mes")
    public void seleccionarDiaProximo(Integer dia) {
        acciones.seleccionarDiaProximo(dia);
    }

    @Entonces("la fecha seleccionada debe mostrarse en el campo de texto")
    public void validarFecha() {
        Assert.assertTrue(acciones.validarFecha());
    }

    @Cuando("intenta escribir una fecha manualmente")
    public void escribirManual() {
        acciones.escribirManual();
    }

    @Entonces("el campo no debe permitir edición manual")
    public void validarCampoBloqueado() {
        Assert.assertTrue(acciones.campoBloqueado());
    }
}
